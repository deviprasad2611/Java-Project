
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;
import javax.net.ssl.*;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class Main {

    private static String USER_NAME = "dmassocbank@gmail.com";  // GMail user name (just the part before "@gmail.com")
    private static String PASSWORD = "9538474629"; // GMail password
    private static String RECIPIENT = "deviprasaddm.16is@saividya.ac.in";

    public static void main(String[] args) {
        
        String[] to =  {RECIPIENT }; // list of recipient email addresses
        String subject = "Dm association bank send mail example";
        String body = "Welcome!";

        sendFromGMail(to, subject, body);
    }

    public static void sendFromGMail(String[] to, String subject, String body) {
    	String from = "dmassocbank@gmail.com"; 
        String pass = "9538474629";
        Properties props = System.getProperties();
        String host = "smtp.gmail.com";
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.user", from);
        props.put("mail.smtp.password", pass);
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        //System.setProperty("https.protocols","TLSv1.2");
        //System.setProperty("jsse.enableSNIExtension","false");
        

        Session session = Session.getDefaultInstance(props);
        session.getProperties().put("mail.smtp.ssl.trust","smtp.gmail.com");
        MimeMessage message = new MimeMessage(session);

        try {
            message.setFrom(new InternetAddress(from));
            InternetAddress[] toAddress = new InternetAddress[to.length];

            // To get the array of addresses
            for( int i = 0; i < to.length; i++ ) {
                toAddress[i] = new InternetAddress(to[i]);
            }

            for( int i = 0; i < toAddress.length; i++) {
                message.addRecipient(Message.RecipientType.TO, toAddress[i]);
            }

            message.setSubject(subject);
            message.setText(body);
            Transport transport = session.getTransport("smtp");
            transport.connect(host, from, pass);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
            System.out.println("Message sent");
        }
        
        catch (Exception me) {
        	JOptionPane p12=new JOptionPane("Sorry, no internet connection.\n But the work has been processed");
        	JDialog d12=p12.createDialog(null,"");
    		d12.setAlwaysOnTop(true);
    		d12.show();
        	System.out.println(me.getMessage());
            me.printStackTrace();
        }
    }
}