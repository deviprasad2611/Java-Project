import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Window;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Panel;
import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.SwingConstants;

import java.awt.Label;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextField;
import javax.swing.JButton;


public class Page_2 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Page_2 frame = new Page_2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Page_2() {
		setResizable(false);
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 100, 800, 450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Panel panel = new Panel();
		panel.setBackground(Color.RED);
		panel.setBounds(48, 0, 700, 50);
		contentPane.add(panel);

		JLabel label = new JLabel("DM ASSOCIATION BANK");
		label.setForeground(Color.WHITE);
		label.setVerticalAlignment(SwingConstants.TOP);
		label.setFont(new Font("High Tower Text", Font.BOLD | Font.ITALIC, 30));
		label.setBackground(Color.WHITE);
		panel.add(label);

		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.RED);
		panel_1.setForeground(Color.RED);
		panel_1.setBounds(0, 50, 50, 313);
		contentPane.add(panel_1);

		Panel panel_2 = new Panel();
		panel_2.setBackground(Color.RED);
		panel_2.setForeground(Color.RED);
		panel_2.setBounds(48, 363, 700, 52);
		contentPane.add(panel_2);

		Panel panel_3 = new Panel();
		panel_3.setBackground(Color.RED);
		panel_3.setBounds(747, 50, 50, 313);
		contentPane.add(panel_3);

		JLabel lblNewLabel = new JLabel("");
		Image img=new ImageIcon(this.getClass().getResource("/dm.png")).getImage();
		lblNewLabel .setIcon(new ImageIcon(img));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel.setBounds(240, 113, 306, 190);
		contentPane.add(lblNewLabel);




		JLabel lblUseDmBank = new JLabel("Use DM BANK ASSOCIATION BANK benfits");
		lblUseDmBank.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblUseDmBank.setHorizontalAlignment(SwingConstants.CENTER);
		lblUseDmBank.setForeground(Color.RED);
		lblUseDmBank.setBounds(215, 84, 367, 32);
		contentPane.add(lblUseDmBank);

		JButton btnExit = new JButton("EXIT");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exit_page e=new exit_page();
				e.setVisible(true);
			}
		});
		btnExit.setBackground(Color.RED);
		btnExit.setForeground(Color.WHITE);
		btnExit.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		btnExit.setBounds(338, 316, 124, 25);
		contentPane.add(btnExit);

		JButton btnTranscationLogs = new JButton("TRANSACTION LOGS");
		btnTranscationLogs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				transcation_logs tl=new transcation_logs();
				tl.setVisible(true);
			}
		});
		btnTranscationLogs.setBackground(Color.RED);
		btnTranscationLogs.setForeground(Color.WHITE);
		btnTranscationLogs.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		btnTranscationLogs.setBounds(71, 286, 157, 25);
		contentPane.add(btnTranscationLogs);

		JButton btnNewButton = new JButton("CHEQUE DEPOSIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cheque_deposit cd=new cheque_deposit();
				cd.setVisible(true);
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnNewButton.setBounds(558, 285, 167, 25);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("PIN CAHNGE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				pinchange_page pi=new pinchange_page();
				pi.setVisible(true);
			}
		});
		btnNewButton_1.setBackground(Color.RED);
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnNewButton_1.setBounds(71, 113, 157, 25);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("BALANCE ENQUIRY");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				banlance_page bp=new banlance_page();
				bp.setVisible(true);
			}
		});
		btnNewButton_2.setBackground(Color.RED);
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		btnNewButton_2.setBounds(71, 173, 156, 25);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("RECHARGE");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				phone_recharge pr=new phone_recharge();
				pr.setVisible(true);
			}
		});
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnNewButton_3.setBackground(Color.RED);
		btnNewButton_3.setBounds(71, 229, 157, 25);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("WITHDRAW");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				withdraw w=new withdraw();
				w.setVisible(true);
			}
		});
		btnNewButton_4.setBackground(Color.RED);
		btnNewButton_4.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnNewButton_4.setForeground(Color.WHITE);
		btnNewButton_4.setBounds(558, 113, 167, 25);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("DEPOSIT");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deposit_page d=new deposit_page();
				d.setVisible(true);
			}
		});
		btnNewButton_5.setForeground(Color.WHITE);
		btnNewButton_5.setBackground(Color.RED);
		btnNewButton_5.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnNewButton_5.setBounds(558, 171, 167, 25);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("TRANSFER");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				transfer_page t=new transfer_page();
				t.setVisible(true);
			}
		});
		btnNewButton_6.setBackground(Color.RED);
		btnNewButton_6.setForeground(Color.WHITE);
		btnNewButton_6.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnNewButton_6.setBounds(560, 229, 165, 25);
		contentPane.add(btnNewButton_6);






	}
}
