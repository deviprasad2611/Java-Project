import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class addbank extends JFrame {

	private JPanel contentPane;
	private JTextField b1;
	private JTextField b2;
	private JTextField b3;
	private JTable table;

	/**
	 * Launch the application.
	 * @throws IOException 
	 */
	public static  String filename="C:\\user\\bank.txt";
	public static void main(String[] args) throws IOException {

		File file=new File(filename);
		file.createNewFile();
		System.out.println(file.exists());

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addbank frame = new addbank();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addbank() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 934, 553);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 928, 50);
		contentPane.add(panel);

		JLabel lblAddBank = new JLabel("ADD  BANK DETAILS");
		lblAddBank.setForeground(Color.WHITE);
		lblAddBank.setFont(new Font("Times New Roman", Font.BOLD, 30));
		panel.add(lblAddBank);

		b1 = new JTextField();
		b1.setHorizontalAlignment(SwingConstants.CENTER);
		b1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		b1.setBounds(46, 132, 364, 39);
		contentPane.add(b1);
		b1.setColumns(10);

		JLabel lblBankName = new JLabel("Bank Name");
		lblBankName.setForeground(Color.RED);
		lblBankName.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblBankName.setBounds(46, 95, 115, 24);
		contentPane.add(lblBankName);

		b2 = new JTextField();
		b2.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		b2.setHorizontalAlignment(SwingConstants.CENTER);
		b2.setBounds(46, 227, 290, 39);
		contentPane.add(b2);
		b2.setColumns(10);

		JLabel lblNewLabel = new JLabel("Bank ID");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel.setBounds(46, 198, 103, 27);
		contentPane.add(lblNewLabel);

		b3 = new JTextField();
		b3.setHorizontalAlignment(SwingConstants.CENTER);
		b3.setForeground(Color.BLACK);
		b3.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		b3.setBounds(46, 347, 290, 39);
		contentPane.add(b3);
		b3.setColumns(10);

		JLabel lblIfscCode = new JLabel("IFSC Code");
		lblIfscCode.setForeground(Color.RED);
		lblIfscCode.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblIfscCode.setBounds(46, 318, 140, 16);
		contentPane.add(lblIfscCode);

		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					String name=b1.getText();
					Pattern po=Pattern.compile("[a-zA-Z]+([ '.][a-zA-Z]+)*" );
					Matcher mo=po.matcher(name);
					boolean to1=mo.find()&&mo.group().equals(name);
					if(to1==false)
					{
						JOptionPane p141=new JOptionPane("Enter proper name");
						JDialog d141=p141.createDialog(null,"");
						d141.setAlwaysOnTop(true);
						d141.show();
						int res141 = 0;
						if(res141==JOptionPane.OK_OPTION)
						{
							b1.setText(null);

						}

					}
					String id=b2.getText();
					String code=b3.getText();
					if(b2.getText()==null||b3.getText()==null)
					{
						JOptionPane p141=new JOptionPane("Enter proper details");
						JDialog d141=p141.createDialog(null,"");
						d141.setAlwaysOnTop(true);
						d141.show();
						int res141 = 0;
						if(res141==JOptionPane.OK_OPTION)
						{
							b1.setText(null);

						}

					}
					String str=b1.getText()+","+b2.getText()+","+b3.getText()+"$";
					if(to1==true)
					{
						System.out.println("here1");
						File file1=new File(filename);

						BufferedReader in =new BufferedReader(new FileReader(filename));
						String mystr;
						boolean flag=true;
						Scanner sc=new Scanner(file1);
						System.out.println("here2");
						String s1=in.readLine();
						System.out.println("s1"+s1);
						if(s1==null)
						{
							System.out.println("here");
							BufferedWriter out=new BufferedWriter(new FileWriter(filename,true));
							out.write(str);
							out.newLine();
							out.close();
							JOptionPane p41=new JOptionPane("Bank details added succesfully");
							JDialog d41=p41.createDialog(null,"");
							d41.setAlwaysOnTop(true);
							d41.show();
							int res41 = 0;
							if(res41==JOptionPane.OK_OPTION)
							{
								b1.setText(null);
								b2.setText(null);
								b3.setText(null);

							}
						}

						else{

							while(sc.hasNextLine())
							{
								mystr=sc.nextLine();
								System.out.println("here");
								System.out.println(mystr);
								String[] values=mystr.split(",");
								for(String i:values)
									System.out.println(i);
								if(values[0].equals(b1.getText()))
								{

									JOptionPane p41=new JOptionPane("Bank details already present");
									JDialog d41=p41.createDialog(null,"");
									d41.setAlwaysOnTop(true);
									d41.show();
									int res41 = 0;
									if(res41==JOptionPane.OK_OPTION)
									{
										b1.setText(null);
										b2.setText(null);
										b3.setText(null);

									}

									flag=false;
									break;

								}
								values=null;


							}

							if(flag==true)
							{
								BufferedWriter out=new BufferedWriter(new FileWriter(filename,true));
								out.write(str);
								out.newLine();
								out.close();

								JOptionPane p41=new JOptionPane("Bank details added succesfully");
								JDialog d41=p41.createDialog(null,"");
								d41.setAlwaysOnTop(true);
								d41.show();
								int res41 = 0;
								if(res41==JOptionPane.OK_OPTION)
								{
									b1.setText(null);
									b2.setText(null);
									b3.setText(null);

								}
							}

						}

					}
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}
			}
		});
		btnAdd.setBackground(Color.RED);
		btnAdd.setForeground(Color.WHITE);
		btnAdd.setFont(new Font("Times New Roman", Font.BOLD, 30));
		btnAdd.setBounds(46, 434, 170, 50);
		contentPane.add(btnAdd);



		JLabel lblBankDetails = new JLabel("Bank details");
		lblBankDetails.setForeground(Color.RED);
		lblBankDetails.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblBankDetails.setBounds(550, 95, 115, 22);
		contentPane.add(lblBankDetails);




		JButton btnRefresh = new JButton("REFRESH");
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					String[] values;
					Object[][] row=new Object[20][3];
					int i=0;
					System.out.println("here3");
					File file1=new File(filename);
					Scanner sc=new Scanner(file1);
					while(sc.hasNextLine())
					{
						String mystr=sc.nextLine();
						System.out.println("here4");
						values=mystr.split(",");
						String ds=values[2].replace('$',' ').trim();
						values[2]=ds;
						for(int j=0;j<values.length;j++)
						{
							System.out.println("here5");
							System.out.println(values[j]);
							row[i][j]=values[j];
							System.out.println(row[i][j]);

						}

						values=null;
						i++;
					}


					Object[] colname={"Bank name","Bank ID","Ifsc Code"};

					table = new JTable(row,colname);
					//table.addColumn();
					JScrollPane scrollp = new JScrollPane(table);
					//table.setModel(DbUtils.resultSetToTableModel(rs));
					System.out.println("ok");
					//	table.setBounds(85,100,100,100);
					table.setBackground(Color.WHITE);
					table.setForeground(Color.BLACK);
					table.setFont(new Font("Times New Roman", Font.PLAIN, 18));
					contentPane.add(table);
					//table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
					scrollp.setViewportView(table);
					scrollp.setBounds(550, 120, 300, 328);
					scrollp.setBackground(Color.WHITE);
					scrollp.setForeground(Color.BLACK);
					scrollp.setFont(new Font("Times New Roman", Font.PLAIN, 18));
					scrollp.getHorizontalScrollBar();
					scrollp.getVerticalScrollBar();
					contentPane.add(scrollp);
				}

				catch(Exception e)
				{
					System.out.println(e);
				}
			}});
		btnRefresh.setBackground(Color.RED);
		btnRefresh.setFont(new Font("Times New Roman", Font.BOLD, 28));
		btnRefresh.setForeground(Color.WHITE);
		btnRefresh.setBounds(295, 434, 170, 50);
		contentPane.add(btnRefresh);





	}
}

