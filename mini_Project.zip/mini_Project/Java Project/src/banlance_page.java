import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Panel;
import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class banlance_page extends JFrame {

	private JPanel contentPane;
	Page_1 pg =new Page_1();
	public String acc=pg.acc;


	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\display.txt";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					banlance_page frame = new banlance_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public banlance_page() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setAlwaysOnTop(true);
		setBounds(300, 170, 550, 391);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Page_2 p=new Page_2();
				p.setVisible(true);
			}
		});
		
		JLabel baln = new JLabel("");
		baln.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		baln.setBounds(172, 244, 279, 27);
		contentPane.add(baln);
		
		JLabel acct = new JLabel("");
		acct.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		acct.setBounds(162, 212, 317, 18);
		contentPane.add(acct);
		
		JLabel accn = new JLabel("");
		accn.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		accn.setBounds(159, 170, 292, 22);
		contentPane.add(accn);
		
		JLabel holdn = new JLabel("\r\n");
		holdn.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		holdn.setBounds(162, 139, 317, 18);
		contentPane.add(holdn);
		
		JLabel bankn = new JLabel("");
		bankn.setHorizontalAlignment(SwingConstants.LEFT);
		bankn.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		bankn.setBounds(162, 65, 317, 22);
		contentPane.add(bankn);

		JLabel lblAccountType = new JLabel("Account type:");
		lblAccountType.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblAccountType.setForeground(Color.RED);
		lblAccountType.setBackground(Color.WHITE);
		lblAccountType.setBounds(23, 208, 118, 22);
		contentPane.add(lblAccountType);
		btnBack.setBackground(Color.RED);
		btnBack.setForeground(Color.WHITE);
		btnBack.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		btnBack.setBounds(174, 291, 150, 35);
		contentPane.add(btnBack);

		Panel panel = new Panel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 532, 50);
		contentPane.add(panel);

		JLabel label = new JLabel("DM ASSOCIATION BANK");
		panel.add(label);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("High Tower Text", Font.BOLD | Font.ITALIC, 23));
		label.setBackground(Color.RED);

		JLabel lblHolderName = new JLabel("Holder name:");
		lblHolderName.setForeground(Color.RED);
		lblHolderName.setBackground(Color.WHITE);
		lblHolderName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblHolderName.setBounds(23, 135, 113, 22);
		contentPane.add(lblHolderName);

		JLabel lblBankName = new JLabel("Bank name:");
		lblBankName.setForeground(Color.RED);
		lblBankName.setHorizontalAlignment(SwingConstants.CENTER);
		lblBankName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblBankName.setBounds(12, 71, 113, 16);
		contentPane.add(lblBankName);

		JLabel label_1 = new JLabel("");
		label_1.setBounds(35, 135, 56, 16);
		contentPane.add(label_1);

		JLabel lblIfscCode = new JLabel("IFSC code:");
		lblIfscCode.setHorizontalAlignment(SwingConstants.CENTER);
		lblIfscCode.setForeground(Color.RED);
		lblIfscCode.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblIfscCode.setBounds(12, 106, 103, 16);
		contentPane.add(lblIfscCode);
		Image img=new ImageIcon(this.getClass().getResource("/dm.png")).getImage();

		JLabel lblAccountNumber = new JLabel("Account number:");
		lblAccountNumber.setForeground(Color.RED);
		lblAccountNumber.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblAccountNumber.setBounds(23, 172, 124, 16);
		contentPane.add(lblAccountNumber);

		JLabel lblBalance = new JLabel("Balance:");
		lblBalance.setForeground(Color.RED);
		lblBalance.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblBalance.setBounds(23, 243, 113, 16);
		contentPane.add(lblBalance);
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setBackground(Color.CYAN);
		lblNewLabel .setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(92, 135, 359, 169);
		contentPane.add(lblNewLabel);
		
		JLabel ifsc = new JLabel("");
		ifsc.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		ifsc.setBounds(172, 100, 320, 22);
		contentPane.add(ifsc);
		try{
			File file1=new File(filename1);
			Scanner sc=new Scanner(file1);
			String[] values={};
			int flag=0;
			while(sc.hasNextLine())
			{
				String mystr=sc.nextLine();
				if(mystr.startsWith("*"))continue;
				System.out.println("here4");
				values=mystr.split(",");
				int pos=values[5].indexOf("$");
				String ds=values[5].substring(0,pos);
				values[5]=ds;
				System.out.println(ds);
				
				if(values[2].equals(acc))
				{
					flag=1;
					break;
					
				}
				values=null;				
			}
			if(flag==1)
			{
				bankn.setText(values[0].toUpperCase());
				ifsc.setText(values[1]);
				holdn.setText(values[3].toUpperCase());
				accn.setText(acc);
				acct.setText(values[4].toUpperCase());
				baln.setText(values[5]);
			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
