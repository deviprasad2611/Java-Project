import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;


public class nextpage extends JFrame {

	private JPanel contentPane;
	public static String bankname;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					nextpage frame = new nextpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public nextpage() {
		setBackground(Color.WHITE);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 934, 553);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.WHITE);
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 952, 45);
		contentPane.add(panel);
		
		JLabel lblEnterDetails = new JLabel("MENU SELECTIONS");
		lblEnterDetails.setFont(new Font("Times New Roman", Font.BOLD, 28));
		lblEnterDetails.setForeground(Color.WHITE);
		lblEnterDetails.setBackground(Color.RED);
		panel.add(lblEnterDetails);
		String[] values= new String[3];
		ArrayList<String> as= new ArrayList<String>();
		try{
			
			
			
			File file1=new File("C:\\user\\bank.txt");
			Scanner sc=new Scanner(file1);
			while(sc.hasNextLine())
			{
				String mystr=sc.nextLine();
				System.out.println("here4");
				values=mystr.split(",");
				as.add(values[0]);
				
				values=null;
				
			}
			
			
 		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("here4");
		System.out.println(as);
		String[] a=new String[as.size()];
		for(int i=0;i<as.size();i++)
		{
			a[i]=as.get(i).toUpperCase();
		}
		JComboBox<String> bankn = new JComboBox<String>();
	
		bankn.setModel(new DefaultComboBoxModel<String>(a));
		bankn.setSelectedIndex(0);
		bankn.setBackground(Color.WHITE);
		bankn.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		bankn.setBounds(325, 133, 316, 28);
		contentPane.add(bankn);
		
		JLabel lblSelectBankName = new JLabel("Select bank name:");
		lblSelectBankName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblSelectBankName.setForeground(Color.RED);
		lblSelectBankName.setBounds(327, 111, 200, 22);
		contentPane.add(lblSelectBankName);
		
		JButton btnNewButton = new JButton("CREATE ACCOUNT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				bankname=bankn.getSelectedItem().toString();
				System.out.println(bankname);
				createacc ac=new createacc();
				ac.setVisible(true);
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(49, 245, 316, 45);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("UPDATE ACCOUNT");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bankname=bankn.getSelectedItem().toString();
				System.out.println(bankname);
				updateacc uc=new updateacc();
				uc.setVisible(true);
			}
		});
		btnNewButton_1.setBackground(Color.RED);
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setBounds(587, 245, 316, 45);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("DELETE ACCOUNT");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bankname=bankn.getSelectedItem().toString();
				System.out.println(bankname);
				deleteacc dc=new deleteacc();
				dc.setVisible(true);
			}
		});
		btnNewButton_2.setBackground(Color.RED);
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_2.setBounds(49, 397, 316, 45);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("VEIW ACCOUNT");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bankname=bankn.getSelectedItem().toString();
				System.out.println(bankname);
				viewacc vc =new viewacc();
				vc.setVisible(true);
			}
		});
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_3.setBackground(Color.RED);
		btnNewButton_3.setBounds(587, 397, 316, 45);
		contentPane.add(btnNewButton_3);
		
		JButton btnAddBank = new JButton("BANK DETAILS");
		btnAddBank.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addbank ad=new addbank();
				ad.setVisible(true);
			}
		});
		btnAddBank.setBackground(Color.RED);
		btnAddBank.setForeground(Color.WHITE);
		btnAddBank.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnAddBank.setBounds(696, 122, 207, 45);
		contentPane.add(btnAddBank);
	}
}
