import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Panel;
import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class pinchange_page extends JFrame {

	private JPanel contentPane;
	private JPasswordField oldpin;
	private JPasswordField newpin;
	private JPasswordField conformpin;
	Page_1 pg =new Page_1();
	public String acc=pg.acc;

	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\account.txt";
	public static  String filename2="C:\\user\\user.txt";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pinchange_page frame = new pinchange_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public pinchange_page() {
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(400, 200, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnNewButton = new JButton("ENTER");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String old=oldpin.getText();
				String newp=newpin.getText();
				String conformp=conformpin.getText();
				Pattern p1=Pattern.compile("[0-9][0-9][0-9]\\d+");
				Matcher m=p1.matcher(old);
				boolean t=m.find()&&m.group().equals(old);
				System.out.println("t="+t);
				Pattern p11=Pattern.compile("[0-9][0-9][0-9]\\d+");
				Matcher m1=p11.matcher(newp);
				boolean t1=m1.find()&&m1.group().equals(newp);
				System.out.println("t="+t);
				Pattern p12=Pattern.compile("[0-9][0-9][0-9]\\d+");
				Matcher m2=p12.matcher(conformp);
				boolean t2=m2.find()&&m2.group().equals(conformp);
				System.out.println("t="+t2);
				if(t1==false||t==false||t2==false)
				{
					JOptionPane p311=new JOptionPane("Enter the Pin Number Properly with atleast 4 numbers");
					JDialog d311=p311.createDialog(null,"");
					d311.setAlwaysOnTop(true);
					d311.show();
				}


				try{
					int flag=0;
					long addr=Math.abs(acc.hashCode()%19937);
					RandomAccessFile raf = new RandomAccessFile(filename1, "rw");
					raf.seek(addr);
					RandomAccessFile raf2 = new RandomAccessFile(filename2, "rw");
					raf2.seek(addr);
					String[] values=raf2.readLine().trim().split(",");
					int pos=values[2].indexOf("$");
					String pinno=values[2].substring(0,pos);
					System.out.println(old);
					boolean b=pinno.equalsIgnoreCase(old);
					System.out.println("ok");
					if(b==true)
					{
						raf.seek(addr);
						String[] values1=raf.readLine().trim().split(",");
						System.out.println(values1[0]);
						if(newp.equals(conformp)&&t==true&&t1==true&&t2==true)
						{
							System.out.println("ok here");
							if(values1[0].equals(acc))flag=1;
							String str=values1[0]+","+newp+","+values1[2]+","+values1[3]+","+values1[4]+","+values1[5]+","+values1[6]+","+values1[7];
							String str1=values[0]+","+values[1]+","+newp+"$";
							System.out.println(str);
							System.out.println(str1);
							System.out.println("ok here1");
							if(flag==1)
							{
								raf.seek(addr);
								raf.writeBytes(str);
								raf2.seek(addr);
								raf2.writeBytes(str1);
								Date df =new Date();
								String[] to={values1[6]};
								String subject="Pin number has been changed for your account number";
								String body="Pin number has been changed for your account "+acc+" on "+df+".Don't reveal your pin number.Total balance is Rs."+values[4]+".";
								System.out.println(body);
								
							    Main.sendFromGMail(to,subject,body);
								

								JOptionPane p31=new JOptionPane("Pin Number Changed Succesfully");
								JDialog d31=p31.createDialog(null,"");
								d31.setAlwaysOnTop(true);
								d31.show();
								int res31 = 0;
								if(res31==JOptionPane.OK_OPTION)
								{
									Page_2 pa=new Page_2();
									pa.setVisible(true);
								}
								
							}
							else
							{

								JOptionPane p23=new JOptionPane("unsuccesfully");
								JDialog d23=p23.createDialog(null,"");
								d23.setAlwaysOnTop(true);
								d23.show();
								int res23 = 0;
								if(res23==JOptionPane.OK_OPTION)
								{
									Page_2 pa=new Page_2();
									pa.setVisible(true);
								}

							}
							
						}
						else if(newp.equals(conformp)==false)
						{

							JOptionPane p2=new JOptionPane("New and confirm pin doesn't match");
							JDialog d2=p2.createDialog(null,"");
							d2.setAlwaysOnTop(true);
							d2.show();
							int res2 = 0;
							if(res2==JOptionPane.OK_OPTION)
							{
								oldpin.setText(null);
								conformpin.setText(null);
								newpin.setText(null);
							}
						}
					}
					else 
					{

						JOptionPane p2=new JOptionPane("Enter proper pin number");
						JDialog d2=p2.createDialog(null,"");
						d2.setAlwaysOnTop(true);
						d2.show();
						int res2 = 0;
						if(res2==JOptionPane.OK_OPTION)
						{
							oldpin.setText(null);
							conformpin.setText(null);
							newpin.setText(null);
						}

					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}






			}
		});

		JLabel lblConfrimPinNumber = new JLabel("CONFIRM PIN NUMBER:");
		lblConfrimPinNumber.setForeground(Color.RED);
		lblConfrimPinNumber.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblConfrimPinNumber.setHorizontalAlignment(SwingConstants.CENTER);
		lblConfrimPinNumber.setBounds(0, 168, 216, 16);
		contentPane.add(lblConfrimPinNumber);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnNewButton.setBounds(136, 215, 130, 25);
		contentPane.add(btnNewButton);

		conformpin = new JPasswordField();
		conformpin.setHorizontalAlignment(SwingConstants.CENTER);
		conformpin.setEchoChar('*');
		conformpin.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		conformpin.setBounds(218, 163, 202, 25);
		contentPane.add(conformpin);

		newpin = new JPasswordField();
		newpin.setHorizontalAlignment(SwingConstants.CENTER);
		newpin.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		newpin.setEchoChar('*');
		newpin.setBounds(218, 119, 202, 25);
		contentPane.add(newpin);

		oldpin = new JPasswordField();
		oldpin.setHorizontalAlignment(SwingConstants.CENTER);
		oldpin.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		oldpin.setEchoChar('*');
		oldpin.setBounds(218, 69, 202, 25);
		contentPane.add(oldpin);

		JLabel lblOldPinNumber = new JLabel("OLD PIN NUMBER:");
		lblOldPinNumber.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblOldPinNumber.setHorizontalAlignment(SwingConstants.CENTER);
		lblOldPinNumber.setForeground(Color.RED);
		lblOldPinNumber.setBounds(12, 71, 158, 16);
		contentPane.add(lblOldPinNumber);

		JLabel lblNewPinNumber = new JLabel("NEW PIN NUMBER:");
		lblNewPinNumber.setForeground(Color.RED);
		lblNewPinNumber.setBackground(Color.WHITE);
		lblNewPinNumber.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewPinNumber.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewPinNumber.setBounds(0, 124, 184, 16);
		contentPane.add(lblNewPinNumber);

		JLabel lblNewLabel = new JLabel("");
		//String img;

		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(78, 71, 274, 151);
		contentPane.add(lblNewLabel);

		Panel panel = new Panel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 444, 40);
		contentPane.add(panel);

		JLabel label = new JLabel("DM ASSOCIATION BANK");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("High Tower Text", Font.BOLD | Font.ITALIC, 20));
		label.setBackground(Color.RED);
		panel.add(label);
		Image img=new ImageIcon(this.getClass().getResource("/dm.png")).getImage();
		lblNewLabel .setIcon(new ImageIcon(img));
	}
}
