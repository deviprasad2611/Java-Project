import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Panel;
import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.SingleSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

//import org.apache.commons.*;
//import org.apache.commons.dbutils.DbUtils;




















import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollBar;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;





public class transcation_logs extends JFrame {

	private JPanel contentPane;
	Page_1 pg =new Page_1();
	public String acc=pg.acc;
	private JTable tp1;
	private JComboBox c1;
	private JTable table;
	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\transaction_logs.txt";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					transcation_logs frame = new transcation_logs();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public transcation_logs() {

		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(300,100,800,450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);


		Panel panel = new Panel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 782, 50);
		contentPane.add(panel);

		JLabel label = new JLabel("DM ASSOCIATION BANK");
		label.setVerticalAlignment(SwingConstants.TOP);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("High Tower Text", Font.BOLD | Font.ITALIC, 30));
		label.setBackground(Color.WHITE);
		panel.add(label);

		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Page_2 pg=new Page_2();
				pg.setVisible(true);
			}
		});
		btnBack.setForeground(Color.WHITE);


		btnBack.setBackground(Color.RED);
		btnBack.setBounds(301, 359, 144, 31);
		contentPane.add(btnBack);





		try{
			String[] values;
			Object[][] row=new Object[50][5];
			int i=0;
			System.out.println("here3");
			File file1=new File(filename1);
			Scanner sc=new Scanner(file1);
			
			while(sc.hasNextLine())
			{
				String mystr=sc.nextLine();
				if(mystr.startsWith("*"))continue;
				System.out.println("here4");
				values=mystr.split(",");
				int pos=values[4].indexOf("$");
				String ds=values[4].substring(0,pos);
				values[4]=ds;
				System.out.println(ds);
				int k=1;
				if(values[0].equals(acc))
				{
					for(int j=0;j<4;j++)
					{
						System.out.println("here5");
						System.out.println(values[j]);
						row[i][j]=values[k];
						System.out.println(row[i][k]);
						k++;
					}
					values=null;
					i++;
				}

				
			}
			Object[] colname={"Amount","Balance","Transaction_Date_Time","Transaction_Type"};
			
			table = new JTable(row,colname);
			
	
			JScrollPane scrollp = new JScrollPane(table);
			System.out.println("ok");
			//	table.setBounds(85,100,100,100);
			table.setBackground(Color.WHITE);
			table.setForeground(Color.BLACK);
			table.setFont(new Font("Times New Roman", Font.PLAIN, 18));
			contentPane.add(table);
			//table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			scrollp.setViewportView(table);
			scrollp.setBounds(85,120,600,200);
			scrollp.setBackground(Color.WHITE);
			scrollp.setForeground(Color.BLACK);
			scrollp.setFont(new Font("Times New Roman", Font.PLAIN, 18));
			scrollp.getHorizontalScrollBar();
			scrollp.getVerticalScrollBar();
			contentPane.add(scrollp);
		}

		catch(Exception e1)
		{
			System.out.println(e1);
		}
	}
}
